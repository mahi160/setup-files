
export function getNames() {
    return [
        'increase-thumbnails-size',
        'hide-search',
        'restore-thumbnails-background',
        'always-show-thumbnails',
        'overview-firefox-pip',
    ];
}
