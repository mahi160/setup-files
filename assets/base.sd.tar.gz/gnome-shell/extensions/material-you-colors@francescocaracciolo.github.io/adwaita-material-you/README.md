# Adwaita Material You

Adwaita Material You is a script to genrate and apply GTK4 themes (and GTK3 with adw-gtk3) based on a color or an image  
